import { ResComponent } from "./components/ResComponent";

window.customElements.define('res-component', ResComponent);